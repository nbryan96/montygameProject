const cards = document.querySelectorAll('.door')

function openDoor(){
console.log('i was clicked')
}

cards.forEach(card => card.addEventListener('click', openDoor))